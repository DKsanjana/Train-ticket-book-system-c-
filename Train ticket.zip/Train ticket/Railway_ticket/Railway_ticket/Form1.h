#pragma once

namespace Railway_ticket {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//

			ComboData();
			Combo2Data();
			filldata();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::GroupBox^  groupBox1;
	protected: 
	private: System::Windows::Forms::Label^  label1;


	private: System::Windows::Forms::GroupBox^  groupBox4;
	private: System::Windows::Forms::GroupBox^  groupBox5;



	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label3;










	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::ComboBox^  comboBox1;



















	private: System::Windows::Forms::GroupBox^ groupBox6;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown3;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown2;
	private: System::Windows::Forms::RadioButton^ radioButton5;
	private: System::Windows::Forms::RadioButton^ radioButton4;
	private: System::Windows::Forms::Label^ label22;
	private: System::Windows::Forms::Label^ label23;
	private: System::Windows::Forms::Label^ label18;
	private: System::Windows::Forms::Label^ label24;









	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label17;
	private: System::Windows::Forms::Label^ label16;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Button^ button1;

	private: System::Windows::Forms::Label^ label26;
	private: System::Windows::Forms::ComboBox^ comboBox3;


	private: System::Windows::Forms::Button^ button2;
	private: System::Drawing::Printing::PrintDocument^ printDocument1;
	private: System::Windows::Forms::PrintPreviewDialog^ printPreviewDialog1;

private: System::Windows::Forms::Button^ button3;
private: System::Windows::Forms::TabPage^ tabPage1;
private: System::Windows::Forms::GroupBox^ groupBox3;
private: System::Windows::Forms::Label^ label37;
private: System::Windows::Forms::Label^ label35;
private: System::Windows::Forms::Label^ label9;
private: System::Windows::Forms::Label^ label2;
private: System::Windows::Forms::Label^ label19;
private: System::Windows::Forms::Label^ label27;
private: System::Windows::Forms::Label^ label36;
private: System::Windows::Forms::Label^ label25;
private: System::Windows::Forms::Label^ label21;
private: System::Windows::Forms::Label^ label30;
private: System::Windows::Forms::Label^ label29;
private: System::Windows::Forms::Label^ label12;
private: System::Windows::Forms::Label^ label28;
private: System::Windows::Forms::Label^ label20;
private: System::Windows::Forms::Label^ label32;
private: System::Windows::Forms::Label^ label34;
private: System::Windows::Forms::Label^ label33;
private: System::Windows::Forms::Label^ label31;
private: System::Windows::Forms::Label^ label13;
private: System::Windows::Forms::Label^ label11;
private: System::Windows::Forms::Label^ label10;
private: System::Windows::Forms::Label^ label15;
private: System::Windows::Forms::Label^ label14;
private: System::Windows::Forms::Label^ label8;
private: System::Windows::Forms::TabControl^ tabControl1;
private: System::Windows::Forms::TabPage^ tabPage2;
private: System::Windows::Forms::RichTextBox^ richTextBox1;






















	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->groupBox5 = (gcnew System::Windows::Forms::GroupBox());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->groupBox6 = (gcnew System::Windows::Forms::GroupBox());
			this->numericUpDown3 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown2 = (gcnew System::Windows::Forms::NumericUpDown());
			this->radioButton5 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton4 = (gcnew System::Windows::Forms::RadioButton());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->printDocument1 = (gcnew System::Drawing::Printing::PrintDocument());
			this->printPreviewDialog1 = (gcnew System::Windows::Forms::PrintPreviewDialog());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->label37 = (gcnew System::Windows::Forms::Label());
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->groupBox1->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox5->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->groupBox6->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown2))->BeginInit();
			this->tabPage1->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->tabControl1->SuspendLayout();
			this->tabPage2->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox1->Location = System::Drawing::Point(0, 0);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(1210, 50);
			this->groupBox1->TabIndex = 0;
			this->groupBox1->TabStop = false;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Minion Pro", 18, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(283, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(351, 42);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Kelani Valley Line Railway";
			this->label1->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// groupBox4
			// 
			this->groupBox4->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->groupBox4->Controls->Add(this->comboBox3);
			this->groupBox4->Controls->Add(this->comboBox2);
			this->groupBox4->Controls->Add(this->comboBox1);
			this->groupBox4->Controls->Add(this->label5);
			this->groupBox4->Controls->Add(this->label4);
			this->groupBox4->Controls->Add(this->label3);
			this->groupBox4->Controls->Add(this->label7);
			this->groupBox4->Controls->Add(this->label26);
			this->groupBox4->Controls->Add(this->label6);
			this->groupBox4->Controls->Add(this->label17);
			this->groupBox4->Controls->Add(this->label16);
			this->groupBox4->Location = System::Drawing::Point(12, 56);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(324, 261);
			this->groupBox4->TabIndex = 0;
			this->groupBox4->TabStop = false;
			// 
			// comboBox3
			// 
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Location = System::Drawing::Point(140, 154);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(54, 24);
			this->comboBox3->TabIndex = 4;
			this->comboBox3->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox3_SelectedIndexChanged);
			// 
			// comboBox2
			// 
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Location = System::Drawing::Point(140, 104);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(145, 24);
			this->comboBox2->TabIndex = 2;
			this->comboBox2->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox2_SelectedIndexChanged);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(140, 64);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(145, 24);
			this->comboBox1->TabIndex = 2;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox1_SelectedIndexChanged);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(15, 104);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(94, 20);
			this->label5->TabIndex = 1;
			this->label5->Text = L"Destination";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(15, 64);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(108, 20);
			this->label4->TabIndex = 1;
			this->label4->Text = L"Starting point";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(99, 18);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(128, 25);
			this->label3->TabIndex = 0;
			this->label3->Text = L"Travel details";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(15, 240);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(131, 20);
			this->label7->TabIndex = 2;
			this->label7->Text = L"Departure time :";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label26->Location = System::Drawing::Point(15, 158);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(79, 20);
			this->label26->TabIndex = 2;
			this->label26->Text = L"Train ID :";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(15, 192);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(134, 20);
			this->label6->TabIndex = 2;
			this->label6->Text = L"Available Seats :";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label17->Location = System::Drawing::Point(178, 242);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(0, 18);
			this->label17->TabIndex = 2;
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label16->Location = System::Drawing::Point(178, 194);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(0, 18);
			this->label16->TabIndex = 2;
			// 
			// groupBox5
			// 
			this->groupBox5->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->groupBox5->Controls->Add(this->dataGridView1);
			this->groupBox5->Controls->Add(this->button1);
			this->groupBox5->Location = System::Drawing::Point(12, 323);
			this->groupBox5->Name = L"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(738, 248);
			this->groupBox5->TabIndex = 0;
			this->groupBox5->TabStop = false;
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(0, 0);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersWidth = 51;
			this->dataGridView1->RowTemplate->Height = 24;
			this->dataGridView1->Size = System::Drawing::Size(738, 213);
			this->dataGridView1->TabIndex = 2;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(19, 219);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(90, 23);
			this->button1->TabIndex = 1;
			this->button1->Text = L"View Data";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// groupBox6
			// 
			this->groupBox6->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->groupBox6->Controls->Add(this->numericUpDown3);
			this->groupBox6->Controls->Add(this->numericUpDown2);
			this->groupBox6->Controls->Add(this->radioButton5);
			this->groupBox6->Controls->Add(this->radioButton4);
			this->groupBox6->Controls->Add(this->label22);
			this->groupBox6->Controls->Add(this->label23);
			this->groupBox6->Controls->Add(this->label18);
			this->groupBox6->Controls->Add(this->label24);
			this->groupBox6->Location = System::Drawing::Point(342, 56);
			this->groupBox6->Name = L"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(408, 261);
			this->groupBox6->TabIndex = 0;
			this->groupBox6->TabStop = false;
			// 
			// numericUpDown3
			// 
			this->numericUpDown3->Location = System::Drawing::Point(104, 106);
			this->numericUpDown3->Name = L"numericUpDown3";
			this->numericUpDown3->Size = System::Drawing::Size(40, 22);
			this->numericUpDown3->TabIndex = 3;
			this->numericUpDown3->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown3_ValueChanged);
			// 
			// numericUpDown2
			// 
			this->numericUpDown2->Location = System::Drawing::Point(104, 66);
			this->numericUpDown2->Name = L"numericUpDown2";
			this->numericUpDown2->Size = System::Drawing::Size(40, 22);
			this->numericUpDown2->TabIndex = 3;
			this->numericUpDown2->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown2_ValueChanged);
			// 
			// radioButton5
			// 
			this->radioButton5->AutoSize = true;
			this->radioButton5->Location = System::Drawing::Point(160, 193);
			this->radioButton5->Name = L"radioButton5";
			this->radioButton5->Size = System::Drawing::Size(72, 21);
			this->radioButton5->TabIndex = 1;
			this->radioButton5->TabStop = true;
			this->radioButton5->Text = L"Return";
			this->radioButton5->UseVisualStyleBackColor = true;
			this->radioButton5->CheckedChanged += gcnew System::EventHandler(this, &Form1::radioButton5_CheckedChanged);
			// 
			// radioButton4
			// 
			this->radioButton4->AutoSize = true;
			this->radioButton4->Location = System::Drawing::Point(28, 193);
			this->radioButton4->Name = L"radioButton4";
			this->radioButton4->Size = System::Drawing::Size(68, 21);
			this->radioButton4->TabIndex = 1;
			this->radioButton4->TabStop = true;
			this->radioButton4->Text = L"Single";
			this->radioButton4->UseVisualStyleBackColor = true;
			this->radioButton4->CheckedChanged += gcnew System::EventHandler(this, &Form1::radioButton4_CheckedChanged);
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label22->Location = System::Drawing::Point(15, 104);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(71, 20);
			this->label22->TabIndex = 1;
			this->label22->Text = L"Children";
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label23->Location = System::Drawing::Point(15, 64);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(56, 20);
			this->label23->TabIndex = 1;
			this->label23->Text = L"Adults";
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label18->Location = System::Drawing::Point(6, 152);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(108, 24);
			this->label18->TabIndex = 0;
			this->label18->Text = L"Ticket Type";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label24->Location = System::Drawing::Point(99, 18);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(116, 25);
			this->label24->TabIndex = 0;
			this->label24->Text = L"Passengers";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(822, 542);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(91, 23);
			this->button2->TabIndex = 1;
			this->button2->Text = L"Print";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// printDocument1
			// 
			this->printDocument1->PrintPage += gcnew System::Drawing::Printing::PrintPageEventHandler(this, &Form1::printDocument1_PrintPage);
			// 
			// printPreviewDialog1
			// 
			this->printPreviewDialog1->AutoScrollMargin = System::Drawing::Size(0, 0);
			this->printPreviewDialog1->AutoScrollMinSize = System::Drawing::Size(0, 0);
			this->printPreviewDialog1->ClientSize = System::Drawing::Size(400, 300);
			this->printPreviewDialog1->Enabled = true;
			this->printPreviewDialog1->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"printPreviewDialog1.Icon")));
			this->printPreviewDialog1->Name = L"printPreviewDialog1";
			this->printPreviewDialog1->Visible = false;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(1010, 542);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 2;
			this->button3->Text = L"Clear";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// tabPage1
			// 
			this->tabPage1->Controls->Add(this->groupBox3);
			this->tabPage1->Controls->Add(this->label8);
			this->tabPage1->Location = System::Drawing::Point(4, 25);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(434, 451);
			this->tabPage1->TabIndex = 0;
			this->tabPage1->Text = L"tabPage1";
			this->tabPage1->UseVisualStyleBackColor = true;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label8->Font = (gcnew System::Drawing::Font(L"Minion Pro", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label8->Location = System::Drawing::Point(63, 3);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(306, 37);
			this->label8->TabIndex = 0;
			this->label8->Text = L"Kelani Valley line railway";
			this->label8->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// groupBox3
			// 
			this->groupBox3->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->groupBox3->Controls->Add(this->label37);
			this->groupBox3->Controls->Add(this->label35);
			this->groupBox3->Controls->Add(this->label9);
			this->groupBox3->Controls->Add(this->label2);
			this->groupBox3->Controls->Add(this->label19);
			this->groupBox3->Controls->Add(this->label27);
			this->groupBox3->Controls->Add(this->label36);
			this->groupBox3->Controls->Add(this->label25);
			this->groupBox3->Controls->Add(this->label21);
			this->groupBox3->Controls->Add(this->label30);
			this->groupBox3->Controls->Add(this->label29);
			this->groupBox3->Controls->Add(this->label12);
			this->groupBox3->Controls->Add(this->label28);
			this->groupBox3->Controls->Add(this->label20);
			this->groupBox3->Controls->Add(this->label32);
			this->groupBox3->Controls->Add(this->label34);
			this->groupBox3->Controls->Add(this->label33);
			this->groupBox3->Controls->Add(this->label31);
			this->groupBox3->Controls->Add(this->label13);
			this->groupBox3->Controls->Add(this->label11);
			this->groupBox3->Controls->Add(this->label10);
			this->groupBox3->Controls->Add(this->label15);
			this->groupBox3->Controls->Add(this->label14);
			this->groupBox3->Location = System::Drawing::Point(6, 36);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(422, 409);
			this->groupBox3->TabIndex = 0;
			this->groupBox3->TabStop = false;
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label14->Location = System::Drawing::Point(30, 145);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(215, 50);
			this->label14->TabIndex = 1;
			this->label14->Text = L"Route \r\n-----------------------------";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label15->Location = System::Drawing::Point(30, 281);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(215, 25);
			this->label15->TabIndex = 1;
			this->label15->Text = L"-----------------------------";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->Location = System::Drawing::Point(35, 206);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(68, 25);
			this->label10->TabIndex = 0;
			this->label10->Text = L"From :";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label11->Location = System::Drawing::Point(35, 256);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(47, 25);
			this->label11->TabIndex = 0;
			this->label11->Text = L"To :";
			this->label11->Click += gcnew System::EventHandler(this, &Form1::label11_Click);
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label13->Location = System::Drawing::Point(191, 371);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(67, 25);
			this->label13->TabIndex = 0;
			this->label13->Text = L"Price :";
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label31->Location = System::Drawing::Point(264, 199);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(56, 18);
			this->label31->TabIndex = 2;
			this->label31->Text = L"Adults :";
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label33->Location = System::Drawing::Point(352, 199);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(0, 18);
			this->label33->TabIndex = 2;
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label34->Location = System::Drawing::Point(352, 243);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(0, 18);
			this->label34->TabIndex = 2;
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label32->Location = System::Drawing::Point(264, 243);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(57, 18);
			this->label32->TabIndex = 2;
			this->label32->Text = L"Childs :";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label20->Location = System::Drawing::Point(114, 70);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(0, 18);
			this->label20->TabIndex = 2;
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label28->Location = System::Drawing::Point(299, 158);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(102, 20);
			this->label28->TabIndex = 2;
			this->label28->Text = L"No.of tickets";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label12->Location = System::Drawing::Point(36, 321);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(105, 20);
			this->label12->TabIndex = 2;
			this->label12->Text = L"Ticket Type :";
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label29->Location = System::Drawing::Point(233, 70);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(55, 20);
			this->label29->TabIndex = 2;
			this->label29->Text = L"Date :";
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label30->Location = System::Drawing::Point(233, 108);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(56, 20);
			this->label30->TabIndex = 2;
			this->label30->Text = L"Time :";
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label21->Location = System::Drawing::Point(114, 211);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(71, 18);
			this->label21->TabIndex = 2;
			this->label21->Text = L"3rd Class";
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label25->Location = System::Drawing::Point(114, 261);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(71, 18);
			this->label25->TabIndex = 2;
			this->label25->Text = L"3rd Class";
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label36->Location = System::Drawing::Point(153, 323);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(71, 18);
			this->label36->TabIndex = 2;
			this->label36->Text = L"3rd Class";
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label27->Location = System::Drawing::Point(264, 376);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(71, 18);
			this->label27->TabIndex = 2;
			this->label27->Text = L"3rd Class";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label19->Location = System::Drawing::Point(25, 22);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(83, 25);
			this->label19->TabIndex = 0;
			this->label19->Text = L"Rer.No :";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(119, 80);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(71, 18);
			this->label2->TabIndex = 2;
			this->label2->Text = L"3rd Class";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(30, 73);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(78, 25);
			this->label9->TabIndex = 0;
			this->label9->Text = L"Class  :";
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->Location = System::Drawing::Point(294, 73);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(54, 17);
			this->label35->TabIndex = 3;
			this->label35->Text = L"label35";
			// 
			// label37
			// 
			this->label37->AutoSize = true;
			this->label37->Location = System::Drawing::Point(294, 111);
			this->label37->Name = L"label37";
			this->label37->Size = System::Drawing::Size(54, 17);
			this->label37->TabIndex = 4;
			this->label37->Text = L"label37";
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tabPage1);
			this->tabControl1->Controls->Add(this->tabPage2);
			this->tabControl1->Location = System::Drawing::Point(756, 56);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(442, 480);
			this->tabControl1->TabIndex = 3;
			// 
			// tabPage2
			// 
			this->tabPage2->Controls->Add(this->richTextBox1);
			this->tabPage2->Location = System::Drawing::Point(4, 25);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(3);
			this->tabPage2->Size = System::Drawing::Size(434, 451);
			this->tabPage2->TabIndex = 1;
			this->tabPage2->Text = L"tabPage2";
			this->tabPage2->UseVisualStyleBackColor = true;
			// 
			// richTextBox1
			// 
			this->richTextBox1->Location = System::Drawing::Point(6, 6);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(422, 439);
			this->richTextBox1->TabIndex = 7;
			this->richTextBox1->Text = L"";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->ClientSize = System::Drawing::Size(1210, 583);
			this->Controls->Add(this->tabControl1);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->groupBox5);
			this->Controls->Add(this->groupBox6);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			this->groupBox5->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->groupBox6->ResumeLayout(false);
			this->groupBox6->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown2))->EndInit();
			this->tabPage1->ResumeLayout(false);
			this->tabPage1->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			this->tabControl1->ResumeLayout(false);
			this->tabPage2->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void label6_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label11_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
	          DateTime idate = DateTime::Now;
	          label35->Text = idate.ToShortDateString();
	          label37->Text = idate.ToShortTimeString();
		 }


	private: System::Void ComboData(void){
		String^ con = "datasource=localhost;port=3306;username=root";
		MySqlConnection^ database = gcnew MySqlConnection(con);
		MySqlCommand^ cmnd = gcnew MySqlCommand("Select DISTINCT Starting_Point from Train.Shedule;", database);
		MySqlDataReader^ rdr;

		try {
			database->Open();
			rdr = cmnd->ExecuteReader();
			while (rdr->Read()) 
			{
				String^ data;
				data = rdr->GetString("Starting_Point");
				comboBox1->Items->Add(data);
			}
		}
		catch (Exception^ ex) 
		{
			//database->Close();
			MessageBox::Show(ex->Message);
		}
	  
	}


	 private: System::Void Combo2Data(void) {
		 String^ con = "datasource=localhost;port=3306;username=root";
		 MySqlConnection^ database = gcnew MySqlConnection(con);
		MySqlCommand^ cmnd = gcnew MySqlCommand("Select DISTINCT Destination from Train.Shedule;", database);
		MySqlDataReader^ rdr;

		 try {
			 database->Open();
			 rdr = cmnd->ExecuteReader();
			 while (rdr->Read())
			 {
				 String^ des;
				 des = rdr->GetString("Destination");
				 comboBox2->Items->Add(des);
			 }
		 }
		 catch (Exception^ ex)
		 {
			 database->Close();
			 MessageBox::Show(ex->Message);
		 }

	 }

private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	label21->Text = comboBox1->Text;
}
private: System::Void comboBox2_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	label25->Text = comboBox2->Text;
}
private: System::Void numericUpDown2_ValueChanged(System::Object^ sender, System::EventArgs^ e) {
	label33->Text = numericUpDown2->Text;
}
private: System::Void numericUpDown3_ValueChanged(System::Object^ sender, System::EventArgs^ e) {
	label34->Text = numericUpDown3->Text;
}
private: System::Void radioButton4_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
	label36->Text = "Single";

}
private: System::Void radioButton5_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
	label36->Text = "Return";
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	String^ con = "datasource=localhost;port=3306;username=root";
	MySqlConnection^ database = gcnew MySqlConnection(con);
	MySqlCommand^ cmnd = gcnew MySqlCommand("Select * from Train.Shedule;", database);
	//MySqlDataReader^ rdr;

	try {
		
		MySqlDataAdapter^ datv = gcnew MySqlDataAdapter();
		datv->SelectCommand = cmnd;
		DataTable^ dtset = gcnew DataTable();
		datv->Fill(dtset);
		BindingSource^ source = gcnew BindingSource();
		 source->DataSource = dtset;
		 dataGridView1->DataSource = source;
		datv->Update(dtset);
	
	}
	catch (Exception^ ex) {
		 database->Close();
		MessageBox::Show(ex->Message);
	}
}
private: System::Void filldata(void) {

	String^ con = "datasource=localhost;port=3306;username=root";
	MySqlConnection^ database = gcnew MySqlConnection(con);
	MySqlCommand^ cmnd = gcnew MySqlCommand("Select ID from Train.Shedule;", database);
	MySqlDataReader^ rdr;

	try {
		database->Open();
		rdr = cmnd->ExecuteReader();
		while (rdr->Read())
		{
			String^ id;
			id = rdr->GetString("ID");
			comboBox3->Items->Add(id);
		}
	}
	catch (Exception^ ex)
	{
		database->Close();
		MessageBox::Show(ex->Message);
	}


	   
}
private: System::Void comboBox3_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	String^ trainID = comboBox3->Text;

	String^ con = "datasource=localhost;port=3306;username=root";
	MySqlConnection^ database = gcnew MySqlConnection(con);
	MySqlCommand^ cmnd = gcnew MySqlCommand("Select * from Train.Shedule where ID='"+trainID+"';", database);
	MySqlDataReader^ rdr;

	try {
		database->Open();
		rdr = cmnd->ExecuteReader();
		if (rdr->Read())
		{
			String^ Tname = rdr->GetString("Train_Name");
			String^ Stime= rdr->GetString("Starting_Time");
			String^ Seat = rdr->GetString("Seats");
			label17->Text = Stime;
			
			int st = Convert::ToInt32(Seat);
			String^ Tprice = rdr->GetString("Price");
			double cprice = Convert::ToInt32(Tprice);

			double numAdults = Convert::ToInt32(numericUpDown2->Text);
			double numchild = Convert::ToInt32(numericUpDown3->Text);
			double total = (cprice * numAdults) + (cprice / 2) * numchild;
			label16->Text = st-(numAdults+numchild)+"/"+Seat;
			if (label36->Text == "Return") {
				double price = total;
				label27->Text = System::Convert::ToString(price * 2) + ".00 LKR";
			}
			else {
				double price = total;
				label27->Text = System::Convert::ToString(price) + ".00 LKR";
			}
		}

		

	}
	catch (Exception^ ex)
	{
		database->Close();
		MessageBox::Show(ex->Message);
	}

	recipt();
}

private: System::Void printDocument1_PrintPage(System::Object^ sender, System::Drawing::Printing::PrintPageEventArgs^ e) {
	String^ draw = richTextBox1->Text;
	System::Drawing::Font^ drawFont = gcnew System::Drawing::Font("calibri", 15);
	SolidBrush^ drawBrush = gcnew SolidBrush(Color::Black);
	PointF drawPoint = Point(150.0F, 150.0F);
	e->Graphics->DrawString(draw, drawFont, drawBrush, drawPoint);

}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	printPreviewDialog1->Document = printDocument1;
	printPreviewDialog1 ->ShowDialog();
}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	label21->Text = "";
	label25->Text = "";
	label36->Text = "";
	label35->Text = "";
	label37->Text = "";
	label27->Text = "";
	label33->Text = "";
	label34->Text = "";
}

	   private: System::Void recipt(void) {
	   
		   richTextBox1->Text = "";
		   richTextBox1->AppendText("\t   Kalani Valley Railway " + Environment::NewLine);
		   richTextBox1->AppendText("\t  *********************** " + Environment::NewLine);
		   richTextBox1->AppendText("\t  Rer.No:"+comboBox3->Text + Environment::NewLine+ Environment::NewLine);
		   richTextBox1->AppendText("\t  Class: 3rd Class" + Environment::NewLine + Environment::NewLine);
		   richTextBox1->AppendText("\t  Route:"+ Environment::NewLine);
		   richTextBox1->AppendText("\t  ----------------------------------" + Environment::NewLine + Environment::NewLine);
		   richTextBox1->AppendText("\t  From : "+label21->Text+  Environment::NewLine);
		   richTextBox1->AppendText("\t  To : " + label25->Text + Environment::NewLine+Environment::NewLine);
		   richTextBox1->AppendText("\t  ---------------------------------" + Environment::NewLine + Environment::NewLine);
		   richTextBox1->AppendText("\t  Ticket Details : " + Environment::NewLine);
		   richTextBox1->AppendText("\t  ---------------------------------" + Environment::NewLine);
		   richTextBox1->AppendText("\t  Ticket Type : " + label36->Text + Environment::NewLine + Environment::NewLine);
		   richTextBox1->AppendText("\t  Adults : " + label33->Text + Environment::NewLine + Environment::NewLine);
		   richTextBox1->AppendText("\t  Childs : " + label34->Text + Environment::NewLine + Environment::NewLine);
		   richTextBox1->AppendText("\t  No of Seats : " + label16->Text + Environment::NewLine + Environment::NewLine);
		   richTextBox1->AppendText("\t  Current Date : " + label35->Text + Environment::NewLine + Environment::NewLine);
		   richTextBox1->AppendText("\t  Current Time : " + label37->Text + Environment::NewLine + Environment::NewLine);
		   richTextBox1->AppendText("\t  Train Time : " + label17->Text + Environment::NewLine);
		   richTextBox1->AppendText("\t  ---------------------------------" + Environment::NewLine);
		   richTextBox1->AppendText ("\t\t\t Price : " + label27->Text + Environment::NewLine);

	   
	   
	   }
};
}



